package com.example.project167.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import com.example.project167.Adapter.PopularAdapter;
import com.example.project167.R;
import com.example.project167.databinding.ActivityMainBinding;
import com.example.project167.domain.PopularDomain;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        statusBarColor();
         initRecyclerView();
         bottomNavigation();
    }

    private void bottomNavigation() {
        binding.cartBtn.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, CartActivity.class)));
    }

    private void statusBarColor() {
        Window window=MainActivity.this.getWindow();
        window.setStatusBarColor(ContextCompat.getColor(MainActivity.this,R.color.purple_Dark));
    }

    private void initRecyclerView() {
        ArrayList<PopularDomain> items=new ArrayList<>();
        items.add(new PopularDomain("เสื้อยืดสีดำ","item_1",15,4,250,"เสื้อยืดสีดำ\n" +
                " ระบายความร้อนได้ดี \n" +
                " Iเนื้อผ้าเบาสบาย\n"
                ));
        items.add(new PopularDomain("Smart Watch","item_2",10,4.5,7000,"นาฬิกาอัจฉริยะ เรียบหรู ดูดี\n" +
                " กันน้ำ กันฝุ่น เหมาะกับการใช้งานในชีวิตประจำวัน\n" ));
        items.add(new PopularDomain("มือถือ","item_3",3,4.9,45000,"รุ่นใหม่ล่าสุด แรง ไม่ร้อน\n" +
                " กล้องคมชัดที่สุดในตอนนี้\n"));

        binding.PopularView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        binding.PopularView.setAdapter(new PopularAdapter(items));
    }
}