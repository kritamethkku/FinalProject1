package com.example.project167.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
